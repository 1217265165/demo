export default[
{ src : "/common/images/1.png"
},
{ src :"/common/images/2.png"
},
{ src :"/common/images/3.png"
}
]
